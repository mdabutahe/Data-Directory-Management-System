from django.apps import AppConfig


class DirectoryAppConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "directory_app"
